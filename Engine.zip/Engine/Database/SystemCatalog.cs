﻿using System.Text.Json;

namespace DB.Engine.Database
{
    /// <summary>
    /// Manages the list of all databases in the DBMS root directory.
    /// Stores and loads metadata (database names, creation time, etc.).
    /// </summary>
    public class SystemCatalog
    {
        private readonly string _catalogFilePath;
        private Dictionary<string, DatabaseInfo> _databases;

        public SystemCatalog(string rootPath)
        {
            _catalogFilePath = Path.Combine(rootPath, "db_catalog.json");
            Load();
        }

        /// <summary>
        /// Checks if a given database exists in the catalog.
        /// </summary>
        public bool Exists(string dbName)
        {
            return _databases.ContainsKey(dbName);
        }


        /// <summary>
        /// Adds a new database to the catalog.
        /// </summary>
        public void AddDatabase(string dbName)
        {
            if (_databases.ContainsKey(dbName))
            {
                throw new InvalidOperationException($"Database '{dbName}' already exists.");
            }

            string dbPath = Path.Combine(Path.GetDirectoryName(_catalogFilePath)!, dbName);
            var info = new DatabaseInfo(dbName, dbPath);
            _databases[dbName] = info;

            Save();
        }

        /// <summary>
        /// Removes a database from the catalog.
        /// </summary>
        public void RemoveDatabase(string dbName)
        {
            if (_databases.Remove(dbName))
                Save();
        }

        /// <summary>
        /// Returns all database names.
        /// </summary>
        public IEnumerable<string> ListDatabases() => _databases.Keys;

        /// <summary>
        /// Loads catalog data from disk.
        /// </summary>
        private void Load()
        {
            if (!File.Exists(_catalogFilePath))
            {
                _databases = [];
                Save();
                return;
            }

            try {
                string json = File.ReadAllText(_catalogFilePath);
                _databases = JsonSerializer.Deserialize<Dictionary<string, DatabaseInfo>>(json)
                    ?? new();
            }
            catch(Exception)
            {
                Console.WriteLine("Corrupted catalog file detected. Reinitializing...");
                _databases = [];
                Save();
            }
        }

        /// <summary>
        /// Saves catalog data to disk.
        /// </summary>
        private void Save()
        {
            string json = JsonSerializer.Serialize(_databases, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_catalogFilePath, json);
        }

        /// <summary>
        /// Returns metadata for all databases.
        /// </summary>
        public IEnumerable<DatabaseInfo> GetAllDatabaseInfo()
        {
            return _databases.Values;
        }
        /// <summary>
        /// Gets the metadata info for a specific database.
        /// </summary>
        public DatabaseInfo? GetInfo(string dbName)
        {
            _databases.TryGetValue(dbName, out var info);
            return info;
        }

        /// <summary>
        /// Marks a database as accessed and updates last access time.
        /// </summary>
        public void MarkAsAccessed(string dbName)
        {
            if (_databases.TryGetValue(dbName, out var info))
            {
                info.UpdateLastAccessed();
                Save();
            }
        }

        /// <summary>
        /// Updates the size info for all databases (optional, heavy operation).
        /// </summary>
        public void RecalculateAllSizes()
        {
            foreach (var db in _databases.Values)
                db.RecalculateSize();

            Save();
        }
    }
}
