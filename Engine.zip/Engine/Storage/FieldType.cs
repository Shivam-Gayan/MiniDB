﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Engine.Storage
{
    public enum FieldType : byte
    {
        Integer = 1,
        String = 2,
        Boolean = 3,
        Double = 4
    }
}
