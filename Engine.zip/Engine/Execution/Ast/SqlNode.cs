﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Engine.Execution.Ast
{
    namespace DB.Engine.Execution.Ast
    {
        /// <summary>
        /// Base class for all SQL AST nodes.
        /// </summary>
        public abstract class SqlNode
        {
        }
    }

}
